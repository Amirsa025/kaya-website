export default class ValidationError {
    messages : {}

    constructor(messages : {}) {
        this.messages = messages;
    }
}

